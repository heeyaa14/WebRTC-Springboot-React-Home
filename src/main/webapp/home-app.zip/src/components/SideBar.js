import { faInstagram } from '@fortawesome/free-brands-svg-icons';
import { faEnvelope, faPhone } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

//사이드메뉴스타일
const SideBarStyle = styled.div`
    font-size: 20px;
    line-height: 1.2;
    font-family: "NG", verdana, applegothic, sans-serif;
    //color: rgba(255, 0, 0, 0.4);
    margin: 0;
    border: 0;
    padding-top:20px;

    @media ${(props) => props.theme.tabletS}{
        display:none;
    }
`;

const LeftNavStyle = styled.div`
    font-size: 20px;
    line-height: 2.5;
    font-family: "NG", verdana, applegothic, sans-serif;
    color: #333;
    margin: 0;
    border: 0;
    position: fixed;
    top: 140px;
    bottom: 0;
    left: 0;
    background: rgba(200, 170, 190, 0.2);
    width: 209px;
    border-right: 1px solid rgb(26, 7, 7);
    z-index: 100;
`; 

const ContentStyle = styled.div`
    font-size: 20px;
    line-height: 2.5;
    font-family: "NG", verdana, applegothic, sans-serif;
    color: #EFF3F4;
    margin: 0;
    padding: 0;
    border: 0;
    width: calc(100% + 18px);
    height: 100%;
    margin-right: 0 !important;
    padding-right: 0 !important;
    padding-bottom: 20px;
    box-sizing: border-box;
    position: absolute;
    top: 0;
    bottom: 0;
    overflow-y: auto;

    @media ${(props) => props.theme.tabletS}{
    display: flex;
    flex-direction: center;
    width: 100%;
    margin: 0;
    border: 0;
    }
`;

const UlStyle = styled.ul`
    font-size: 12px;
    line-height: 1.2;
    font-family: "NG",verdana,applegothic,sans-serif;
    color: #EFF3F4;
    margin: 0;
    padding: 0;
    border: 0;
    list-style: none;
    text-align: center;
    margin-right: 16px;
`;

const LiStyle = styled.li`
    font-size: 25px;
    line-height: 3;
    font-family: "NG",verdana,applegothic,sans-serif;
    color: #EFF3F4;
    list-style: none;
    text-decoration:none;
    margin: 0;
    padding: 0;
    border: 0;
    overflow: hidden;
    border-bottom: 4px solid rgb(26, 7, 7);
    transition: height 0.4s cubic-bezier(0,1,0.5,1);
    cursor: pointer;
    :hover{
        color:lightgray;
        text-shadow:0 0 10px #EFF3F4;
    }
    :link{
        text-decoration:none;
    }

    :visited{
        text-decoration:none;
    }
`;

const InfoBox = styled.div`
    margin:0;
    padding:0;
    padding-top:120px;
`;

const InfoUl = styled.ul`
    padding:0;
    padding-left:10px;
`;

const InfoLi = styled.li`
    list-style:none;
    font-size:13px;
`;

const SideBar = () => {
    return (
        <div>
            <SideBarStyle className="sidebar">
            <LeftNavStyle className="leftnav">
                <ContentStyle className="menustyle">
                    <UlStyle>
                        <LiStyle>방만들기</LiStyle>
                        <LiStyle>랭킹</LiStyle>
                        <LiStyle>카메라</LiStyle>
                        <Link to="/boardList"><LiStyle>자유게시판</LiStyle></Link>
                        <Link to="/gamePage"><LiStyle>게임</LiStyle></Link>
                    </UlStyle>
                <InfoBox>       
                    <InfoUl>
                        <InfoLi><FontAwesomeIcon icon={faPhone} /> 070-1111-2222</InfoLi>
                        <InfoLi><FontAwesomeIcon icon={faInstagram} /> @homedrinker</InfoLi>
                        <InfoLi><FontAwesomeIcon icon={faEnvelope} /> homedk@gmail.com</InfoLi>
                    </InfoUl>
                </InfoBox>
                </ContentStyle>     
            </LeftNavStyle>
        </SideBarStyle>

        </div>
    );
};

export default SideBar;