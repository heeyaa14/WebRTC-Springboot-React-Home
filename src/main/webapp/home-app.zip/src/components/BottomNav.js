import React from 'react';
import styled from 'styled-components';

const NavStyle = styled.section`
    display:none;
    @media ${(props) => props.theme.tabletS}{            
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        position: relative;
        background: #eee;
		text-align: center;
		padding: 0 2em;
    }
`;

const ItemBox = styled.div`
@media ${(props) => props.theme.tabletS}{   
    display: flex;
    flex-direction: row;
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 70px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    background: #fff;
    z-index: 10;
}
`;

const LinkStyle = styled.a`
    display: flex;
    justify-content: center;
    align-items: center;
    flex: 1;
    color: #000;
    letter-spacing: 0.1rem;
		transition: all 0.5s ease;
		font-size: 0.8rem;
        text-decoration:none;
	  &:hover {
        color:lightgray;
        text-shadow:0 0 10px #EFF3F4;
    }
`;

const BottomNav = () => {
    return (
        <div>
            <NavStyle>
                <ItemBox>
      <LinkStyle class="et-hero-tab" href="#">홈</LinkStyle>
      <LinkStyle class="et-hero-tab" href="#">방만들기</LinkStyle>
      <LinkStyle class="et-hero-tab" href="#">카메라</LinkStyle>
      <LinkStyle class="et-hero-tab" href="#">마이페이지</LinkStyle>
                </ItemBox>
            </NavStyle>
        </div>
    );
};

export default BottomNav;