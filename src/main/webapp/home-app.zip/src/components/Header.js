import React, { Children, useState } from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import Button from '@material-ui/core/Button';
import Drawer from '@material-ui/core/Drawer';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import { List, makeStyles,Menu,withStyles,MenuItem  } from '@material-ui/core';
import Modal from '@material-ui/core/Modal';
import clsx from 'clsx';
import Login from '../pages/member/Login';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../store';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle } from '@fortawesome/free-solid-svg-icons';

//헤더스타일
const WrapStyle = styled.div`
    //position:relative;
`;

const HeaderStyle = styled.header`
  display:block;
  position:relative;
  font-family:'Noto Sans KR', sans-serif;
  width: 100%;
  height:100px;
  font-weight: 400;
  line-height: 1.25;
  font-size: 100%;
`;

const TitleStyle = styled.div`
    
`;

const TitleImg =styled.img`
    width:200px;
    height:120px;
`;

const IconStyle = styled.div`
    position: absolute;
    top: 0;
    right: 0;
    margin-top:18px;
    padding-top:40px;
    padding-right:110px;
    /*z-index: 20;
     width: 50px;
    height: 40px; */
    background:url(img/user.png) no-repeat 0 0;
    background-size:45px;
    text-indent: -999em;
    cursor: pointer;
`;

const LoginBtn = styled.button`
    -webkit-font-smoothing: antialiased;
    position: absolute;
    top: 0;
    right: 0;
    margin-top: 30px;
    margin-right: 25px;
    border: none;
    background-color: transparent;
    color:#EFF3F4;
    font-size: 1.1em;
    cursor: pointer; 
    :focus{
      border:0;
      outline:0;  
    }

    @media ${(props) => props.theme.tabletS}{
        margin-right:0;
        right:95px;
    }
`;

const MenuBar = styled.div`
    display:none;
    @media ${(props) => props.theme.tabletS}{
        position: absolute;
        display:block;
        top: 0;
        right: 0;
        margin-right:30px;  
        margin-top: 30px;
    }
`;


//검색창스타일
const SearchAreaStyle = styled.div`
    font-size: 12px;
    line-height: 1.2;
    font-family: "NG", verdana, applegothic, sans-serif;
    color: #333;
    margin: 0;
    padding: 0;
    border: 0;
    position: absolute;
    top: 30px;
    right: 140px;
    width: 246px;
    z-index: 10;

    @media ${(props) => props.theme.tabletS}{
        display:none;   
    }
`;

const FieldStyle = styled.fieldset`
    font-size: 12px;
    line-height: 1.2;
    font-family: "NG", verdana, applegothic, sans-serif;
    color: #333;
    margin: 0;
    padding: 0;
    border: 0;
`;

const SearchForm = styled.form`
    font-size: 12px;
    line-height: 1.2;
    font-family: "NG", verdana, applegothic, sans-serif;
    color: #333;
    margin: 0;
    padding: 0;
    border: 0;
`;

const SearchDiv = styled.div`
    font-size: 12px;
    line-height: 1.2;
    font-family: "NG", verdana, applegothic, sans-serif;
    color: #333;
    margin: 0;
    padding: 0;
    overflow: hidden;
    position: relative;
    background: #fff;
    width: 244px;
    min-height: 31px;
    border: 1px solid black;
    border-radius: 3px;
`;

const SearchInput = styled.input`
    margin: 0;
    outline: none;
    font-family: inherit;
    position: absolute;
    top: 0;
    background: none;
    width: 203px;
    padding: 8px 0 7px 9px;
    border: 0 none;
    color: #181818;
    font-size: 14px;
`;

const SearchBtn = styled.button`
    font-family: "NG", verdana, applegothic, sans-serif;
    color: #333;
    overflow: visible;
    margin: 0;
    padding: 0;
    outline: none;
    position: absolute;
    top: 0;
    right: 3px;
    background: url(/img/search.png) center no-repeat;
    background-size: 19px 19px;
    width: 29px;
    height: 29px;
    border: 0 none;
    z-index: 10;
    cursor: pointer;
    vertical-align: top;
`;

const useStyles = makeStyles({
    list: {
      width: 250,
    },
    fullList: {
      width: 'auto',
    },
  });
  

  const StyledMenu = withStyles({
    paper: {
      border: '1px solid #d3d4d5',
    },
  })((props) => (
    <Menu
      elevation={0}
      getContentAnchorEl={null}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'center',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'center',
      }}
      {...props}
    />
  ));
  
  const StyledMenuItem = withStyles((theme) => ({
    root: {
      '&:focus': {
        backgroundColor: theme.palette.primary.main,
        '& .MuiListItemIcon-root, & .MuiListItemText-primary': {
          color: theme.palette.common.white,
        },
      },
    },
  }))(MenuItem);


const Header = () => {
    const isLogin = useSelector((store) => store.isLogin);
    const dispatch = useDispatch();

    const logoutProc = () => {
        localStorage.removeItem("Authorization");
        dispatch(logout());
    }

    const classes = useStyles();
    const [state, setState] = React.useState({
      top: false,
    });
  
    const toggleDrawer = (anchor, open) => (event) => {
      if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
        return;
      }
  
      setState({ ...state, [anchor]: open });
    };

    const List = (anchor) => (
        <div
          className={clsx(classes.list, {
            [classes.fullList]: anchor === 'top'
          })}
          role="presentation"
          onClick={toggleDrawer(anchor, false)}
          onKeyDown={toggleDrawer(anchor, false)}
        >
          <List>
            {['친구', '게임', '자유게시판', '고객센터'].map((text, index) => (
              <ListItem button key={text}>
                
                <ListItemText primary={text} />
              </ListItem>
            ))}
          </List>
        </div>
      );


  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

    return (
        <WrapStyle>
            <HeaderStyle className="headerstyle">
            <TitleStyle className="titlestyle">
                <Link to ="/"><TitleImg src="/img/logo.png"/></Link>
            </TitleStyle>
            <SearchAreaStyle>
                <FieldStyle>
                    <SearchForm>
                        <input type="hidden" id="szSearchType" name="szSearchType" value="total" />
                        <input type="hidden" name="szStype" value="" />
                        <SearchDiv>
                            <SearchInput type="text" id="szKeyword" name="szKeyword" autocomplete="off" />
                            <SearchBtn type="button" class="btn_search"></SearchBtn>
                        </SearchDiv>
                    </SearchForm>
                </FieldStyle>
            </SearchAreaStyle>

            {!isLogin ? (
                      <>
                      
                      <Link to="/login"><LoginBtn type="button">로그인</LoginBtn></Link>
            
                      </>) 
                        :
                      (<>
                      
                      <IconStyle
                        aria-controls="customized-menu"
                        aria-haspopup="true"
                        variant="contained"
                        onClick={handleClick}
                      />
                      <StyledMenu
                          id="customized-menu"
                          anchorEl={anchorEl}
                          keepMounted
                          open={Boolean(anchorEl)}
                          onClose={handleClose}
                      >
                     
                    <StyledMenuItem> 
                      <ListItemText onClick={logoutProc} primary="로그아웃"/>
                    </StyledMenuItem>
                  </StyledMenu>
                  </>)}
            {/* {isLogin ? 
                (
                    <>
                        <Link onClick={logoutProc}><LoginBtn>로그아웃</LoginBtn></Link>
                    </>
                )
                :
                (
                    <>
                        <Link to="/login"><LoginBtn type="button">로그인</LoginBtn></Link>
                    </> 
                )
            } */}
            
            {/* 
            로그인시
            <IconStyle>
                Usericon
            </IconStyle> */}

            <MenuBar>
            {['top'].map((anchor) => (
        <React.Fragment key={anchor}>
          <Button onClick={toggleDrawer(anchor, true)}>{anchor}</Button>
          <Drawer anchor={anchor} open={state[anchor]} onClose={toggleDrawer(anchor, false)}>
            {List(anchor)}
          </Drawer>
        </React.Fragment>
      ))}
            </MenuBar>

        </HeaderStyle>
        </WrapStyle>
    );
};

export default Header;