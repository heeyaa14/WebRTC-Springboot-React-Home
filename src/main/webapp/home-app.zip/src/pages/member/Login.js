import React, { useState } from 'react';
import styled from "styled-components";
import { useDispatch } from 'react-redux';
import { login } from '../../store';

const ContainerStyle = styled.div`
    background-color: #FFFFFF;
    width: 400px;
    height: 400px;
    margin: 7em auto;
    border-radius: 1.5em;
    box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
`;

const FormStyle = styled.form`
    padding-top: 40px;
`;

const SignStyle = styled.p`
    text-align: center;
    padding-top: 40px;
    color: #8C55AA;
    font-family: 'Ubuntu', sans-serif;
    font-weight: bold;
    font-size: 23px;
`;

const InputStyle = styled.input`
    width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    margin-bottom: 50px;
    margin-left: 46px;
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Ubuntu', sans-serif;
    &:focus {
        outline: none;
        box-shadow: 0px 0px 2px orange;
    }
`;

const LoginBtnStyle = styled.button`
    cursor: pointer;
    border-radius: 5em;
    color: #fff;
    background: linear-gradient(to right, #9C27B0, #E040FB);
    border: 0;
    padding-left: 40px;
    padding-right: 40px;
    padding-bottom: 10px;
    padding-top: 10px;
    font-family: 'Ubuntu', sans-serif;
    margin-left: 35%;
    font-size: 13px;
    box-shadow: 0 0 20px 1px rgba(0, 0, 0, 0.04);
`;

const JoinStyle = styled.p`
    text-shadow: 0px 0px 3px rgba(117, 117, 117, 0.12);
    color: #E1BEE7;
    padding-top: 15px;
    text-align: center;
`;

const JoinAstyle = styled.a`
    text-shadow: 0px 0px 3px rgba(117, 117, 117, 0.12);
    color: #E1BEE7;
    text-decoration: none;
    
`;

const Login = (props) => {

    const dispatch = useDispatch();
    const [member, setMember] = useState({
        id: "",
        password: "",
      });
    
      const loginBtn = (e) => {    
          e.preventDefault();
          fetch("http://localhost:8000/login", {
            method: "POST",
            headers: {
              'Content-Type': "application/json; charset=utf-8"
            }, body: JSON.stringify(member)
          }).then(res => {
    
            // 로컬스토리지에 로그인정보를 저장함.
            for (let header of res.headers.entries()) {
              if (header[0] === "Authorization") {
                localStorage.setItem("Authorization", header[1]);
              }
            }
            return res.text();
          }).then(res => {
    
            if(res==="ok"){ 
              dispatch(login());
              alert(member.id+"님 환영합니다!");
              props.history.push("/");
            } else {
              alert("아이디 혹은 비밀번호가 틀렸습니다!");
            }
          });
      }
    
    const inputHandle = (e) => {
        setMember({ ...member, 
          [e.target.name]: e.target.value });
    }

    return (
    <ContainerStyle>
        <SignStyle align="center">Sign in</SignStyle>
        <FormStyle>
          <InputStyle type="text" name="id" value={member.id} placeholder="Id" onChange={inputHandle}/>
          <InputStyle type="password" name="password" align="center" value={member.password} placeholder="Password" onChange={inputHandle}/>
          <LoginBtnStyle onClick={loginBtn}>Login</LoginBtnStyle>
          <JoinStyle><JoinAstyle href="/join">Join Member</JoinAstyle></JoinStyle>
        </FormStyle>        
                    
    </ContainerStyle>    
    );
};

export default Login;