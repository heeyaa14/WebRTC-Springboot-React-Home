import React, { Component, useState } from "react";  
import styled from "styled-components";

const ContainerStyle = styled.div`
    background-color: #FFFFFF;
    width: 650px;
    height: 850px;
    margin: 7em auto;
    border-radius: 1.5em;
    box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
`;

const PStyle = styled.p`
    text-align: center;
    padding-top: 40px;
    color: #8C55AA;
    font-family: 'Ubuntu', sans-serif;
    font-weight: bold;
    font-size: 23px;
`;

const FormStyle = styled.form`
    padding-top: 40px;
    text-align: center;
`;

const InputStyle = styled.input`
    width: 80%;
    height: 50px;
    color: rgb(38, 50, 56);
    font-weight: 600;
    font-size: 14px;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px 20px;
    border: none;
    border-radius: 10px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    margin-bottom: 50px;
    text-align: center;
    margin-bottom: 15px;
    font-family: 'Ubuntu', sans-serif;
    &:focus {
        outline: none;
        box-shadow: 0px 0px 2px #8C55AA;
    }
`;

const KStyle = styled.div`
  margin: 0 auto;
  width: 60%;
  height: 20px;
  font-size: 13px;
  padding-bottom: 30px;
  margin-bottom: 25px;
  font-weight: 600;
  color: red;
`;

const GenderStyle = styled.p`
    color: rgb(38, 50, 56);
    font-weight: 600;
    font-size: 16px;
    text-align: center;
    margin-bottom: 40px;
`;

const SubmitBtn = styled.input`
    cursor: pointer;
    border-radius: 5em;
    color: #fff;
    background: linear-gradient(to right, #9C27B0, #E040FB);
    border: 0;
    padding-left: 40px;
    padding-right: 40px;
    padding-bottom: 10px;
    padding-top: 10px;
    font-family: 'Ubuntu', sans-serif;
    font-size: 16px;
    box-shadow: 0 0 20px 1px rgba(0, 0, 0, 0.04);
`;



const IdentityBox = styled.div`
    width:80px;
    height:20px;
    //display: flex;
    justify-content:center;
    align-items:center;
    margin: 5px 10px 20px 450px;
`;

const IdentityListStyles = styled.div`
    
`;

const IdentityListBox = styled.div`
    width: 300px;
    height: 200px;
`;

const IdentityModalStyles = {
    content : {
        top                   : '50%',
        left                  : '50%',
        right                 : 'auto',
        bottom                : 'auto',
        marginRight           : '-50%',
        transform             : 'translate(-50%, -50%)'
    }
};

class JoinForm extends Component {
  constructor() {
    super();

    this.state = {
      formFields: {
        id: '',
        password: '',
        username: '',
        email: '',
        phone: '',
        gender: ''
      },
      inputPhoneNumber:'',

      errors: {}
    }
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
      this.handleSMS = this.handleSMS.bind(this);
    };
   
    // When any field value changed
    handleChange(e) {
      let formFields = this.state.formFields;
      formFields[e.target.name] = e.target.value;
      this.setState({
        formFields,
      });

      this.setState({
        [e.target.name]: e.target.value
      });
    }
   
    // To validate all form fields
    validate() {
      let formFields = this.state.formFields;

      let errors = {};
      let IsValid = true;

      
      if (!formFields["id"]) {
        IsValid = false;
        errors["id"] = "Enter Your id";        
      }
       
        // To allow only alphabets value
      if (typeof formFields["id"] !== "undefined") {

        // 영문 소문자, 숫자 4~20자리로 입력
        if (!formFields["id"].match(/^[a-z0-9]{4,20}$/)) {
          IsValid = false;
          errors["id"] = "영문 소문자와 숫자 4~20자리로 입력";
        }
      }

      // Should have valid password format
      if (typeof formFields["password"] !== "undefined") {

        // 6~20 영문 대소문자 | 최소 1개의 숫자 혹은 특수 문자를 포함
        if (!formFields["password"].match(/^(?=.*[a-zA-Z])((?=.*\d)|(?=.*\W)).{6,15}$/)) {
          IsValid = false;
          errors["password"] = "Enter Your Password";
        }
      }

      if (typeof formFields["username"] !== "undefined") {
        var pattern1 = new RegExp(/^[가-힣]{2,6}$/);    // 2~6자리의 한글입력
        if (!pattern1.test(formFields["username"])) {
          IsValid = false;
          errors["username"] = "Enter Your username";
        }
      }

      if (typeof formFields["email"] !== "undefined") {
        var pattern2 = new RegExp(/^[a-z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)?@[a-z][a-zA-Z-0-9]*\.[a-z]+(\.[a-z]+)?$/);
        if (!pattern2.test(formFields["email"])) {
          IsValid = false;
          errors["email"] = "Enter Your email";
        }
      }

      if (typeof formFields["phone"] !== "undefined") {
        var pattern3 = new RegExp(/^01(?:0|1|[6-9])-(?:\d{3}|\d{4})-\d{4}$/);
        if (!pattern3.test(formFields["phone"])) {
          IsValid = false;
          errors["phone"] = "Enter Your phoneNumber";
        }
      }
      
      if (!formFields["gender"]) {
        IsValid = false;
        errors["gender"] = "Select Your gender";        
      }

      this.setState({
        errors: errors
      });
      return IsValid;
    }
    
      // When user submits the form after validation
      handleSubmit(e) {
        e.preventDefault();
        
        if (this.validate()) {
          let formFields = {};

          formFields["id"] = "";
          formFields["password"] = "";
          formFields["username"] = "";
          formFields["email"] = "";
          formFields["phone"] = "";
          formFields["gender"] = "";

          this.setState({ formFields: formFields });

          fetch("http://localhost:8000/join",{
                method:"POST",
                body: JSON.stringify({  
                  id: this.state.formFields.id,
                  password: this.state.formFields.password,
                  username: this.state.formFields.username,
                  email: this.state.formFields.email,
                  phone: this.state.formFields.phone,
                  gender: this.state.formFields.gender,                
                }),
                headers:{
                    'Content-Type':"application/json; charset=utf-8"
                }
                }).then(res=>res.text())
                .then((res)=>{
                if(res === "ok"){
                    alert("회원가입이 완료되었습니다.");
                    //BrowserRouter.push('/login');
                } else {
                  alert("가입 실패")
                }
          });         
        }   
    }

    handleSMS =(e)=> {
      e.preventDefault();
      console.log("phone : "+this.state.inputPhoneNumber);
      this.setState({
        inputPhoneNumber:'',
      });

      let inputPhoneNumber = this.state.inputPhoneNumber;
      //alert("인증번호 발송완료");
      
      fetch("http://localhost:8000/sendSMS", {
        method:"post",
        headers:{
          'Content-Type':"application/json; charset=utf-8"
        },
        body: JSON.stringify ({
          inputPhoneNumber : this.state.inputPhoneNumber,
        })
      }).then(res=>res.text())
      .then(res => {
        console.log("인증번호 : "+res);
        if(res === "ok") {
          alert("전송완료!")
        }
      })

      fetch("http://localhost:8000/sendSMS", {
        method:"get",
        data: {
          "inputPhoneNumber" : inputPhoneNumber,
        }
      }).then(res=>res.json())
      .then(res => {
        console.log("인증번호 : "+res);
      })
  }
    // componentDidMount(){
    //   // eslint-disable-next-line no-undef
    //   $('#sendPhoneNumber').click(function(){
    //     // eslint-disable-next-line no-undef
    //     let phoneNumber = $('#inputPhoneNumber').val();
    //     // eslint-disable-next-line no-undef;
    
    //     Swal.fire('인증번호 발송 완료!')


    //     // eslint-disable-next-line no-undef
    //     $.ajax({
    //         type: "GET",
    //         url: "/check/sendSMS",
    //         data: {
    //             "phoneNumber" : phoneNumber
    //         },
    //         success: function(res){
    //             // eslint-disable-next-line no-undef
    //             $('#checkBtn').click(function(){
    //                 // eslint-disable-next-line no-undef
    //                 if($.trim(res) === $('#inputCertifiedNumber').val()){
    //                     // eslint-disable-next-line no-undef
    //                     $.ajax({
    //                         type: "GET",
    //                         url: "/update/phone",
    //                         data: {
    //                             // eslint-disable-next-line no-undef
    //                             "phoneNumber" : $('#inputPhoneNumber').val()
    //                         }
    //                     })

    //                     // eslint-disable-next-line no-undef
    //                     Swal.fire(
    //                         '인증성공!',
    //                         '휴대폰 인증이 정상적으로 완료되었습니다.',
    //                         'success'
    //                     ).then((OK)=> {
    //                         if(OK){
    //                             window.location.href= "/user/mypage/home";
    //                         }
    //                     })

    //                 }else{
    //                     // eslint-disable-next-line no-undef
    //                     Swal.fire({
    //                         icon: 'error',
    //                         title: '인증오류',
    //                         text: '인증번호가 올바르지 않습니다!',
    //                         footer: '<a href="/home">다음에 인증하기</a>'
    //                     })
    //                 }
    //             })


    //         }
    //     })
    //   });
    // }
  

  render() {

    return (
    <ContainerStyle className="container">

    {/* <Modal
        isOpen={IdentitymodalIsOpen}
        onAfterOpen={IdentityafterOpenModal}
        onRequestClose={IdentitycloseModal}
        style={IdentityModalStyles}
        contentLabel="modal"
    >
      <IdentityListBox>
        <IdentityListStyles>
          <div>
            <h2>SMS 본인인증</h2>
          </div>
          <div>
            <input class="form-control form-control-user" type="text" id="inputPhoneNumber"
                               placeholder="01012345678" onChange={this.handleChange}/>
            <br />
            <a class="btn btn-secondary" id="sendPhoneNumber" onClick={this.handleSMS}>번호확인</a>
            <a id="collapseBtn" class="col-auto btn btn-outline-dark mx-auto" data-toggle="collapse"
                       href="#collapse" role="button" aria-expanded="false" aria-controls="collapseExample">
                        인증번호입력하기
            </a>

          </div>
        </IdentityListStyles>
      </IdentityListBox>   
      <button type="button" class="btn btn-secondary" data-dismiss="modal">취소</button>
      <button type="button" class="btn btn-primary" id="checkBtn">확인</button>
      <button onClick={IdentitycloseModal}>close</button>            
    </Modal> */}


      <PStyle>Join Form</PStyle>
      <FormStyle id="needs-validation" onSubmit={this.handleSubmit}>

        <div className="form-group">
          <InputStyle class="form-control"
            type="text"
            name="id"
            placeholder="Id (영문 4~20자리)"
            value={this.state.formFields.id}
            onChange={this.handleChange} />
          {this.state.errors.id &&
            <KStyle className="alert alert-danger">
              {this.state.errors.id}
            </KStyle>
          }
          {/*---------------------------------- 문자인증폼 ----------------------------------*/}
            <div>
            <div class="modal-body">
                <h5 class="text-center">휴대폰 인증</h5>
                <div class="row">
                    <div class="col">
                        <input class="form-control form-control-user" type="text" id="inputPhoneNumber"
                               name="inputPhoneNumber" placeholder="01012345678" value={this.state.inputPhoneNumber} onChange={this.handleChange}/>
                    </div>
                    <div class="col-auto">
                        <a class="btn btn-secondary" id="sendPhoneNumber" onClick={this.handleSMS}>번호확인</a>
                    </div>
                </div>
                <div class="text-center small mt-2" id="checkMsgNick"></div>

                <div class="row align-items-center">
                    <a id="collapseBtn" class="col-auto btn btn-outline-dark mx-auto" data-toggle="collapse"
                       href="#collapse" role="button" aria-expanded="false" aria-controls="collapseExample">
                        인증번호입력하기
                    </a>
                </div>
                <div class="collapse mt-3" id="collapse">
                    <div class="form-group">
                        <input type="text" class="form-control form-control-user"
                               id="inputCertifiedNumber" placeholder="인증번호입력" />
                    </div>

                    <div class="text-center small mt-2" id="checkMsgPW"></div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">취소</button>
                <button type="button" class="btn btn-primary" id="checkBtn">확인</button>
            </div>
        </div>
        </div>

        <div className="form-group">
          <InputStyle class="form-control"
            type="password"
            name="password"
            placeholder="Password (영문+숫자 6~20자리)"
            value={this.state.formFields.password}
            onChange={this.handleChange} />
          {this.state.errors.password &&
            <KStyle className="alert alert-danger">
              {this.state.errors.password}
            </KStyle>
          }
        </div>
        <div className="form-group">
          <InputStyle class="form-control"
            type="text"
            name="username"
            placeholder="Username (한글 2~6자리)"
            value={this.state.formFields.username}
            onChange={this.handleChange} />
          {this.state.errors.username &&
            <KStyle className="alert alert-danger">
              {this.state.errors.username}
            </KStyle>
          }
        </div>
        <div className="form-group">
          <InputStyle class="form-control"
            type="text"
            name="email"
            placeholder="Email (ex) abc@naver.com"
            value={this.state.formFields.email}
            onChange={this.handleChange} />
          {this.state.errors.email &&
            <KStyle className="alert alert-danger">
              {this.state.errors.email}
            </KStyle>
          }
        </div>
        <div className="form-group">
          <InputStyle class="form-control"
            type="text"
            name="phone"
            placeholder="Phone (ex) 000-1111-2222"
            value={this.state.formFields.phone}
            onChange={this.handleChange} />
          {this.state.errors.phone &&
            <KStyle className="alert alert-danger">
              {this.state.errors.phone}
            </KStyle>
          }
        </div>
        <div class="form-group">
            <GenderStyle> 
                남 <input type="radio" name="gender" value="남" onChange={this.handleChange} />&nbsp;&nbsp;
                여 <input type="radio" name="gender" value="여" onChange={this.handleChange}/>
            </GenderStyle>
        </div>
        <SubmitBtn type="submit" id="btn-save" class="btn btn-primary" value="Sign up"/>
      </FormStyle>
    </ContainerStyle>
    );
  }
}

export default JoinForm;