import React, { useState } from 'react';
import { useQuill } from 'react-quilljs';
import 'quill/dist/quill.snow.css';
import styled from "styled-components";

const BoardFormStyle = styled.div`
   
`;

const BoardInputStyle = styled.input`

`;

const WriteBtnStyle = styled.button`

`;

const BoardForm = (props) => {

    const [board, setBoard] = useState({
        title:"",
        content:"",
    });

    const { quill, quillRef } = useQuill();
 
    const submitBoard = (e) => {
        e.preventDefault();
        changeValue(e);

        fetch("http://localhost:8000/write", {
            method:"post",
            headers: {
                'Content-Type':'application/json; charset=utf-8',
                'Authorization': localStorage.getItem("Authorization")
            }, body: JSON.stringify(board)
        }).then(res=>res.text())
        .then((res)=> {
            if(res === "ok") {
                alert("게시글이 등록되었습니다!");
                props.history.push("/boardList");
            } else {
                alert("게시글 등록 실패!");
            }
        });
    };

    const changeValue = (e)=> {
        document.querySelector(".ql-editor").setAttribute('title','content');
		
		board.content= quill.root.innerHTML;
		
	 	// console.log(board.title);
         // console.log(board.content);
         
	 	console.log({...board, 
	 		[e.target.name]: e.target.value });
	 	setBoard({...board, 
	 		[e.target.name]: e.target.value });
    } 

    return (
        <BoardFormStyle>
			<h1>글쓰기</h1>

			<div>
			제목 <BoardInputStyle type="text" name="title" id="title" onChange={changeValue}  />
			</div>
			<div>내용
				<div  style={{ height: 300 }}>
      				<div ref={quillRef} />
				</div>
			</div>
            <br /><br /><br /><br />
			<div>
			<WriteBtnStyle type="submit" onClick={submitBoard}>등록하기</WriteBtnStyle>
			</div>
		</BoardFormStyle>
    );
};

export default BoardForm;