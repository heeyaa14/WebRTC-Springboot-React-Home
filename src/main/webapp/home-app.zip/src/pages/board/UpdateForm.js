import React, { useEffect, useState } from 'react';
import { useQuill } from 'react-quilljs';
import styled from "styled-components";

const BoardFormStyle = styled.div`

`;

const BoardInputStyle = styled.input`

`;

const WriteBtnStyle = styled.button`

`;

const UpdateForm = (props) => {

    const { quill, quillRef } = useQuill();

	let boardNo = props.match.params.bno;

	const [board, setBoard] = useState({
		title: "",
		content: ""
	});

    const updateBoard = (e)=> {
        e.preventDefault();
        changeValue(e);

        fetch("http://localhost:8000/update/"+boardNo, {
            method:"put",
            headers: {
                "Content-Type":"application/json; charser=utf-8",
				"Authorization":localStorage.getItem("Authorization")
            }, body: JSON.stringify(board)
        }).then(res=>res.text())
        .then((res)=>{
            if(res === "ok") {
                alert("게시글이 수정되었습니다.");
                props.history.push("/boardList");
            } else {
                alert("수정 실패!")
            }
        })
    }

    useEffect( ()=> {
        fetch("http://localhost:8000/boardDetail/"+boardNo, {
            method:"get",
            headers:{
                "Authorization":localStorage.getItem("Authorization")
            }
        }).then(res=>res.json())
        .then(res => {
            setBoard(res);
            var changeContent = res.content.replace(/(<([^>]+)>)/ig,"");  //자바스크립트 정규식으로 태그제거
			var boardC = document.createTextNode(changeContent);
            var qlEditor = document.querySelector(".ql-editor");

            console.log(boardC);
            qlEditor.appendChild(boardC);
        });
    }, []);

    const changeValue = (e)=> {
        setBoard({ ...board, [e.target.name]: e.target.value });
		board.content= quill.root.innerHTML;
    }

    return (
        <BoardFormStyle>
			<h1>게시글 수정</h1>

			<div>
			제목 <BoardInputStyle type="text" name="title" value={board.title} onChange={changeValue}  />
			</div>
			<div>내용
				<div  style={{ height: 300 }}>
      				<div ref={quillRef} />
				</div>
			</div>
            <br /><br /><br /><br />
			<div>
			<WriteBtnStyle type="submit" onClick={updateBoard}>수정하기</WriteBtnStyle>
			</div>
		</BoardFormStyle>
    );
};

export default UpdateForm;