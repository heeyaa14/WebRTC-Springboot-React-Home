import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styled from "styled-components";
import Header from '../../components/Header';
import SideBar from '../../components/SideBar';

const TableStyle = styled.table`
    border: 1px solid white;
    text-align: center;
`;

const TrStyle = styled.tr`
    border: 1px solid white;   
`;

const ThStyle = styled.th`
    border: 1px solid white;   
`;

const Detail = (props) => {

    let boardNo = props.match.params.bno; 
    const [board, setBoard] = useState({
        title:"",
        content:"",
        reg_date:"",
    });
    
    useEffect(() => {
        fetch("http://localhost:8000/boardDetail/"+ boardNo, {
            method:"get",
            headers: {
                "Authorization": localStorage.getItem("Authorization")
            }
        }).then(res=>res.json())
        .then((res) => {
            setBoard(res);
            var changeContent = res.content.replace(/(<([^>]+)>)/ig,"");  //자바스크립트 정규식으로 태그제거
            var boardC = document.createTextNode(changeContent);
            
            console.log(boardC);

        });
    }, []);
    
    const deleteBoard = (boardNo) => {
        fetch("http://localhost:8000/delete/"+boardNo, {
            method:"delete",
            headers: {
                "Authorization": localStorage.getItem("Authorization")
             }
        }).then(res => res.text())
        .then((res)=> {
            if(res === "ok") {
                alert("삭제 성공!");
            } else {
                alert("삭제 실패");
            }
        });
    }

    return (
        <div>
            <Header />
            <SideBar />
            <div align="center">
            <h2>게시글 상세보기</h2><br /><br />
            <TableStyle width="400px" height="400px">
                <TrStyle>
                    <ThStyle>제목</ThStyle><td>{board.title}</td>
                </TrStyle>
                <TrStyle>
                    <ThStyle>내용</ThStyle><td><div dangerouslySetInnerHTML={ {__html: board.content} }></div></td>
                </TrStyle>
                <TrStyle>   
                    <ThStyle>작성자</ThStyle><td>user1</td>
                </TrStyle>
                <TrStyle>
                    <ThStyle>등록일</ThStyle><td>{board.reg_date}</td>
                </TrStyle>
            </TableStyle>
            <br /><br />
            <Link to={"/updateForm/"+board.bno}>수정</Link>
            <button onClick={()=>deleteBoard(board.bno)}>삭제</button>
            </div>
        </div>
    );
};

export default Detail;