import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styled from "styled-components";
import BottomNav from '../../components/BottomNav';
import Header from '../../components/Header';
import SideBar from '../../components/SideBar';

const ContainerStyle = styled.div`
    position:relative;
    text-align: center;
    margin-left:350px;
`;

const TableStyle = styled.table`
    position:relative;
    align-items:center;
    border:0;
    width:70%;
    border-bottom:1px solid #999;
    color:#666;
    font-size:14px;
    //table-layout:fixed;
    text-align: center;
    background-color: white;
`;

const ThStyle = styled.th`
    border:0;
    padding:5px 0 6px;
    border-top:solid 1px #999;
    border-bottom:solid 1px #b2b2b2;
    background-color:#f1f1f4;
    color:#333;
    font-weight:bold;
    line-height:20px;
    vertical-align:top;
`;

const TdStyle = styled.td`
    border:0;
    padding:8px 0 9px;
    border-bottom:solid 1px #d2d2d2;
    text-align:center;
    line-height:18px;
`;

const BoardLinkStyle = styled.p`
    -webkit-font-smoothing: antialiased;
    position: absolute;
    top: 0;
    right: 0;
    margin-top: 50px;
    margin-bottom: 50px;
    margin-right: 270px;
    border: 1px solid white;
    padding: 4px;
    background-color: transparent;
    color:#EFF3F4;
    font-size: 1.1em;
    cursor: pointer; 
    :focus{
      border:0;
      outline:0;  
    }
`;


/*
const aStyle = styled.a`
    color:#383838;
    text-decoration:none;
`;

/*

.sub_news .date,.sub_news .hit{padding:0;font-family:Tahoma;font-size:11px;line-height:normal}
.sub_news .title{text-align:left; padding-left:15px; font-size:13px;}
.sub_news .title .pic,.sub_news .title .new{margin:0 0 2px;vertical-align:middle}
.sub_news .title a.comment{padding:0;background:none;color:#f00;font-size:12px;font-weight:bold}
.sub_news tr.reply .title a{padding-left:16px;background:url(첨부파일/ic_reply.png) 0 1px no-repeat}
*/
const BaordList = (props, {bno, title, content, reg_date}) => {

    const [boards, setBoards] = useState([]);

    const [board, setBoard] = useState({
        bno:"",
        title:"",
        content:"",
        reg_date:"",
    });

	//const [last, setLast] = useState('');
	//const [page, setPage] = useState(0);

    /*
    const [user,setUser]= useState({
        mno:null,
    });
    */
	useEffect(() => {
        
        // flogList 페이징해서 화면에 표시.
        fetch("http://localhost:8000/boardList", {
            method: "GET"
        }).then(res => res.json())
            .then(res => {
                console.log(res);
                setBoards(res.content);
                //setLast(res.last);
        });
        //setUser({...user,mno:JSON.parse(localStorage.getItem("user")).mno});
    }, []);



    return (
    <div>
        <Header />
        <SideBar />
        <br /><br />

        <ContainerStyle>
        <Link to="/boardForm"><BoardLinkStyle>글쓰기</BoardLinkStyle></Link>
        <br /><br />
        <TableStyle>
            <colgroup>
                <col width="90"/>
                <col />
                <col width="110"/>
                <col width="110"/>
            </colgroup>
        
                
            <thead>
                <tr>
                    <ThStyle>No</ThStyle>
                    <ThStyle>제목</ThStyle>
                    <ThStyle>작성자</ThStyle>
                    <ThStyle>등록일</ThStyle>
                </tr>
            </thead>
            {boards.map((board)=> (
            <tbody>
                <tr>
                    <TdStyle>{board.bno}</TdStyle>
                    <TdStyle><Link to={"/boardDetail/"+ board.bno}>{board.title}</Link></TdStyle>

                    <TdStyle>user1</TdStyle>
                    <TdStyle>{board.reg_date}</TdStyle>
                </tr>
            </tbody>
            ))}
        </TableStyle>
        </ContainerStyle>
        <BottomNav />
    </div>
    );
};

export default BaordList;