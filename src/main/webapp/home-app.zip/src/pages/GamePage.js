import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import BottomNav from '../components/BottomNav';
import Header from '../components/Header';
import SideBar from '../components/SideBar';


//프레임스타일
const FrameStyle = styled.div`
    position: relative;
    margin:0;
    left: 14%;
    border:1px solid #EFF3F4;
    border-radius:10px ;
    width:85%;
    height:100%;
    box-shadow:
        //0 0 10px #fff,
		 0 0 20px #ff00de;  
		 /* 0 0 70px #ff00de,
		 0 0 80px #ff00de,
		 0 0 100px #ff00de,
         0 0 150px #ff00de; */
         
    @media ${(props) => props.theme.tabletS}{
        position:relative;
        width:100%;
        left:0;
    }     
`;

const H1Style = styled.h1`
    text-align:center;
`;

const ItemContainer = styled.div`
    text-align:center;
    margin:0;
    justify-items:center;
align-items:center;
`;

const ItemList = styled.div`
    line-height: 1.25;
    white-space: nowrap;
    position: relative;
    display:flex;
    flex-direction:row;
    justify-content:space-around;
    z-index: 10;
    overflow: hidden;
    min-height: 100%;
    width: 100%;
    touch-action: pan-y;
    user-select: none;
    -webkit-user-drag: none;
    height: 134px;
    height: 100%;
    will-change: transform;
    transform: translate3d(0px, 0px, 0px);
    padding:50px 10px;
`;

const ItemBox = styled.div`
    border:1px white solid;
    padding:10px;
    margin:10px;
    width:350px;
    height:300px;
    padding:0;
`;

const ImgStyle1 = styled.div`
    border-bottom:1px white solid;
    height:75%;
    background-image: url('img/onTo.png');
    background-size:cover;
`;

const ImgStyle2 = styled.div`
    border-bottom:1px white solid;
    height:75%;
    background-image: url('img/tic.png');
    background-size:cover;
`;

const ImgStyle3 = styled.div`
    border-bottom:1px white solid;
    height:75%;
    background-image: url('img/RSP.png');
    background-size:cover;
`;

const TitleStyle = styled.div`
    background-color:lightgray;
    color:black;
    font-weight:bolder;
    font-size:1.7em;
    height:25%;
    padding:0;
`;


const GamePage = () => {
    
    return (
        <div>
        <Header/>
        <SideBar/>
        <FrameStyle>
            <H1Style>게임 Zone</H1Style>
            <ItemContainer>
                <ItemList>
                    <ItemBox>
                        <ImgStyle1></ImgStyle1>
                        <Link to="/onetofifty"><TitleStyle>순발력게임</TitleStyle></Link>
                    </ItemBox>
                    <ItemBox>
                        <ImgStyle2></ImgStyle2>
                        <Link to="/ticTacToeGame"><TitleStyle>TicTacToeGame</TitleStyle></Link>
                    </ItemBox>
                    <ItemBox>
                        <ImgStyle3></ImgStyle3>
                        <Link to="/rsp"><TitleStyle>가위바위보</TitleStyle></Link>
                    </ItemBox>
                </ItemList>
                
            </ItemContainer>
        </FrameStyle>
        <BottomNav/>
        </div>
    );
};

export default GamePage;