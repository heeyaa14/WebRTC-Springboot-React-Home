import './App.css';
import { Route, Switch } from "react-router-dom";

import { useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { login } from './store';
import JoinForm from './pages/member/JoinForm';
import Login from './pages/member/Login';
import BoardForm from './pages/board/BoardForm';
import BoardList from './pages/board/BoardList';
import Detail from './pages/board/Detail';
import UpdateForm from './pages/board/UpdateForm';
//import Front from './components/games/RSP/Front';
import Main from './Main'
import GamePage from './pages/GamePage';
import OneToFifty from './games/OneToFifty';
import TicTacToeGame from './tic/TicTacToeGame';
import RSP from './games/RSP';


function App() {

  const dispatch = useDispatch();

  useEffect(()=> {
    let jwtToken = localStorage.getItem("Authorization");
    
    if (jwtToken !== null) {
      dispatch(login());
    }
  },[]);

  return (
    <div className="all">
      <Switch>
        <Route path="/" exact={true} component={Main}/>
      </Switch>
      <Route path="/join" exact={true} component={JoinForm}></Route>
      <Route path="/login" exact={true} component={Login}></Route>
      <Route path="/boardForm" exact={true} component={BoardForm}></Route>
      <Route path="/boardList" exact={true} component={BoardList}></Route>
      <Route path="/boardDetail/:bno" exact={true} component={Detail}></Route>
      <Route path="/updateForm/:bno" exact={true} component={UpdateForm}></Route>
      <Route path="/gamePage" exact={true} component={GamePage}></Route>
      <Route path="/onetofifty" exact={true} component={OneToFifty}></Route>
      <Route path="/ticTacToeGame" exact={true} component={TicTacToeGame}></Route>
      <Route path="/rsp" exact={true} component={RSP}></Route>
    </div>
  );
}

export default App;
