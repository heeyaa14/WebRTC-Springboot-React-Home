import React from 'react';
import BottomNav from './components/BottomNav';
import Header from './components/Header';
import SideBar from './components/SideBar';
import styled from 'styled-components';

//프레임스타일
const FrameStyle = styled.div`
    position: relative;
    margin-top:50px;
    left: 14%;
    border:1px solid #EFF3F4;
    border-radius:10px ;
    width:85%;
    height:100%;
    box-shadow:
        //0 0 10px #fff,
		 0 0 20px #ff00de;  
		 /* 0 0 70px #ff00de,
		 0 0 80px #ff00de,
		 0 0 100px #ff00de,
         0 0 150px #ff00de; */
         
    @media ${(props) => props.theme.tabletS}{
        position:relative;
        width:100%;
        left:0;
    }     
`;

const ContainerStyle = styled.div`
    display: flex;
    flex-wrap: wrap;
    justify-content:center;
    font-size: 12px;
    font-family: "NG", verdana, applegothic, sans-serif;
    color: #EFF3F4;
    margin: 100px;
    padding: 0;

    @media ${(props) => props.theme.tabletS}{
        
    }
`;

const ItemUl = styled.ul`
    display: flex;
    flex-wrap: wrap;
    font-size: 12px;
    line-height: 1.2;
    font-family: "NG", verdana, applegothic, sans-serif;
    margin: 0;
    padding: 0;
    border: 0;
    list-style: none;
    margin-right: -10px;

    @media ${(props) => props.theme.tabletS}{
        display:flex;
        flex-direction:column;
        justify-content:space-around;
        
    }
    
`;

const ItemLi = styled.li`
    font-size: 12px;
    line-height: 1.2;
    font-family: "NG", verdana, applegothic, sans-serif;
    list-style: none;
    padding: 35px;
    //padding-right:35px;
    //display: flex;
    text-align: -webkit-match-parent;
    margin: 0;
    width: 350px;
    padding-top:40px;
    float:left;
    //flex: 0 1 auto;

    @media ${(props) => props.theme.tabletS}{
        justify-content:space-around;
        margin: 20px;

       
        
    }
`;

const ItemImg = styled.div`
    font-size: 12px;
    line-height: 1.2;
    font-family: "NG", verdana, applegothic, sans-serif;
    list-style: none;
    margin: 0;
    padding: 0;
    border: 0;
    position: relative;
`;

const ImgStyle = styled.img`
    list-style: none;
    font: 0/0 a;
    padding: 0;
    border: 0;
    max-width: 100%;
    height:200px;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    width: 100%;
    margin: auto;

`;

const ItemInfo = styled.div`
    font-size: 12px;
    line-height: 1.2;
    font-family: "NG", verdana, applegothic, sans-serif;
    list-style: none;
    margin: 0;
    padding: 0;
    border: 0;
    position: relative;
    min-height: 107px;
    margin-top: 11px;
    @media ${(props) => props.theme.tabletS}{
        position: relative;
        margin:0;
        
        
    }
`;

const TitleStyle = styled.h3`
line-height: 1.2;
font-family: "NG", verdana, applegothic, sans-serif;
font-size:1.5em;
list-style: none;
margin: 0;
padding: 0;
padding-top:120px;
padding-left:20px;
border: 0;
display: flex;
`;



const Main = () => {

    return (
    <div className="wrap">
          
            <Header />
            <SideBar/>
            <FrameStyle>
            <ContainerStyle>
                <ItemUl>
                    <ItemLi>
                        
                        <ItemImg>
                            <ImgStyle src="/img/content.webp"/>
                        </ItemImg>
                        <ItemInfo>
                            <TitleStyle>플레이리스트 1시간</TitleStyle>
                        </ItemInfo>
                        
                    </ItemLi>    
                    <ItemLi>
                        
                        <ItemImg>
                            <ImgStyle src="/img/content.webp"/>
                        </ItemImg>
                        <ItemInfo>
                            <TitleStyle>플레이리스트 1시간</TitleStyle>
                        </ItemInfo>
                        
                    </ItemLi>     
                    <ItemLi>
                        
                        <ItemImg>
                            <ImgStyle src="/img/content.webp"/>
                        </ItemImg>
                        <ItemInfo>
                            <TitleStyle>플레이리스트 1시간</TitleStyle>
                        </ItemInfo>
                       
                    </ItemLi>


                </ItemUl>
            </ContainerStyle>
        </FrameStyle>
        <BottomNav/>

    </div>
    );
};

export default Main;