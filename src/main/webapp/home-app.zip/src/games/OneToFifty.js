import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';
import Board2 from './Board2';
import Timer from './Timer';

const Container = styled.div`
  width: 600px;
  height: 800px;
  border: 1px solid black;
  display: flex;
  justify-content: center;
  align-items: center;
`;

const ExitBtn = styled.button`
    margin: 10px;
`;

const StartButton = styled.button`
  margin-top: 60px;
  width: 100px;
  height: 50px;
  font-weight: bold;
  background-color: lightblue;
`;
let array = [];

for(let i =1; i<=16; i++){
array.push(i);
}
const shuffleArray = (array) => {
    for(let i = array.length -1; i >0; i--){
        let j = Math.floor(Math.random() * (i+1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
};
const OneToFifty = () => {
   
    const [numbers , setNumbers] = useState(array);
    const [gameFlag , setGameFlag] = useState(false);
    const [current , setCurrent] = useState(1);
   

    const handleClick = (num) => {
        if(num === current && gameFlag){
            if(num === 30){
               endGame();
            }
    const index = numbers.indexOf(num);
    setNumbers(numbers => [
        ...numbers.slice(0, index),
        num < 15 ? num+16 :0,
        ...numbers.slice(index+1)
    ]);
    setCurrent(current => current + 1);
}

};
const startGame = () => {
    setNumbers(shuffleArray(array));
    setCurrent(1);
    setGameFlag(true);
};

const endGame = () => {
 setGameFlag(false);
};


    return (
    <div>
        <Link to="/gamePage"  ><ExitBtn>나가기</ExitBtn></Link>
        <div align="center">
          
            <Container>
                    <Board2 numbers={numbers} handleClick={handleClick}/>
                    {gameFlag ? ( 
                        <Timer />
                    ) : (
                        <StartButton onClick={startGame}>start</StartButton>
                    )} 
                   
            </Container>
           
        </div>
    </div>
    );
};

export default OneToFifty;