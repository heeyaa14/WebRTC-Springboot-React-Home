import React from 'react';
import styled from 'styled-components';
import Cell from './Cell';


const Container = styled.div`
  width: 400px;
  height: 400px;
  border: 1px solid blue;
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(4, 1fr);
`;

const Board2 = ({numbers, handleClick}) => {
    return (
        
        <Container>
         {numbers.map((num, index) => (
                <Cell num={num} key={index} handleClick={handleClick}/>
          ))}
        </Container>
      
      
    );
};

export default Board2;