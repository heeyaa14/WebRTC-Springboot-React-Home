import React, { Component } from 'react';
import Square from './Square';
import styles from './TicTacToeGame.module.css'
class Board extends Component {
    renderSquare(i) {
        return (<Square 
                  value={this.props.squares[i]}
                  onClick={() => this.props.onClick(i)}
                  />);
      }

      render() {
        if (!this.props.player) {
            return null;
        }
          
    return (
        <div>
        <div className={styles.game}>
      <div>
        <div className={styles.square}>
          {this.renderSquare(0)}
          {this.renderSquare(1)}
          {this.renderSquare(2)}
        </div>
        <div className={styles.square}>
          {this.renderSquare(3)}
          {this.renderSquare(4)}
          {this.renderSquare(5)}
        </div>
        <div className={styles.square}>
          {this.renderSquare(6)}
          {this.renderSquare(7)}
          {this.renderSquare(8)}
        </div>
      </div>
      </div>
      </div>
    );
};

}

export default Board;