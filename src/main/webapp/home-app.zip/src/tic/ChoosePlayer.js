import React from 'react';
import Square from './Square';
import styles from './TicTacToeGame.module.css'
const ChoosePlayer = (props) => {
    const { onClick, player } = props;  
    if (player) {
        return null;
      }
    return (
        <div>
        <div className={styles.game}>
        <div className={styles.square}>
          <Square 
            value="X"
            onClick={() => onClick("X")}
            />
          <Square 
            value="O"
            onClick={() => onClick("O")}
            />
        </div>
      </div>
      </div>
    );
};

export default ChoosePlayer;