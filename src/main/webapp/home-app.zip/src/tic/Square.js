import React from 'react';
import styles from './TicTacToeGame.module.css'
const Square = (props) => {
    const { onClick, value } = props;
    return (
        <div>
            <button 
      className={styles.square}
      onClick={onClick}>
      {value}
    </button>
        </div>
    );
};

export default Square;